#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int serie(int N){
	int i,r,p,s=0;
	if (N==1){
		return 1;
	}
	else{
		for(i=1;i<=N;i++){
			p=pow(-1,i);
			switch(i){
				case 1:
					r=1;
				break;
				default:
					if(p==-1){
						r=pow(i,i);
					}
					else{
						r=-1*pow(i,i);
					}
				break;
			}
			s+=r;
		}
		return s;
	}
}

int main(int argc, char *argv[]) {
	int n;
	printf("Ingrese el valor de N: ");
	scanf("%d",&n);
	printf("El resultado es: %d",serie(n));
	return 0;
	system("pause");
}
