#include <stdio.h>
#include <stdlib.h>

int factorial(int num);

int main(int argc, char *argv[]) {
	int n;
	printf("Ingrese el numero a calcular ");
	scanf("%d",&n);
	printf("El factorial del numero %d es %d\n",n,factorial(n));
	system("pause");
	return 0;
}

int factorial(int num){
	if(num==0){
		return 1;
	}
	else{
		return(factorial(num-1)*num);
	}
	
}
