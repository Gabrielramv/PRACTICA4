#include <stdio.h>
#include <stdlib.h>
#define g 9.81

float peso(float masa){
	float pes;
	pes= masa*g;
	return pes;
}

float Presion (float f, float area){
	float PresionH;
	PresionH=f/area;
	return PresionH;
}

float Volumen (float area, float carrera){
	float v;
	v=area*carrera;
	return v;
}

int main(int argc, char *argv[]){
	int i;
	float carr, m, pesos[4], Presion_Hidro[4], a;


	printf ("\nIntroduce la secci�n transversal del cilindro %d: ",i+1);
	scanf ("%f", &a);

	for (i=0;i<=3;i++){
		if (i<2){
			printf ("\nPara la carga 1 introduce el valor de la masa %d: ",i+1);
			scanf ("%f", &m);
		}
		else{
			printf ("\nPara la carga 2 introduce el valor de la masa %d: ",i+1);
			scanf ("%f", &m);
		}
		pesos[i]=peso (m);
		Presion_Hidro[i]=Presion (pesos[i],a);
	}	
	for (i=0;i<=3;i++){
		printf ("\nCilindro %d\n", i+1);


		printf ("\nPeso: %.2f\n", pesos[i]);


		printf ("\nPresion: %f\n", Presion_Hidro[i]);
	}
	printf ("\nDame la carrera del cilindro: ");
	scanf ("%f", &carr);
	
	printf ("\nEl volumen es de: %.2f\n",Volumen (a, carr));


	

	system("PAUSE");
	return 0;


}
