#include <stdio.h>
#include <stdlib.h>

float resistencia(float V,float I){
	float r;
	r=V/I;
	return r;
}

float voltaje(float R,float I){
	float v;
	v=R*I;
	return v;
}

float corriente(float V,float R){
	float i;
	i=V/R;
	return i;
}

int main(int argc, char *argv[]) {
	int x;
	float v,r,i;
	printf("Indique que desea calcular 1)Resistencia 2)Voltaje 3)Corriente\n");
	scanf("%d",&x);
	switch(x){
		case 1:
			printf("Indique el valor del voltaje: ");
			scanf("%f",&v);
			printf("Indique el valor de la corriente: ");
			scanf("%f",&i);
			printf("El valor de la resistencia es de %f\n",resistencia(v,i));
		break;
		case 2:
			printf("Indique el valor de la resistencia: ");
			scanf("%f",&r);
			printf("Indique el valor de la corriente: ");
			scanf("%f",&i);
			printf("El valor de la recistencia es de %f\n",voltaje(r,i));
		break;
		case 3:
			printf("Indique el valor del voltaje: ");
			scanf("%f",&v);
			printf("Indique el valor de la recistencia: ");
			scanf("%f",&r);
			printf("El valor de la recistencia es de %f\n",corriente(v,r));
		break;
		default:
			printf("Opcion incorrecta");
		break;
	}
	system("pause");
	return 0;
}
