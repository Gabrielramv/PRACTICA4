#include <stdio.h>
#include <stdlib.h>
#include <math.h>

float CX(float r,float an);
float CY(float r,float an);

int main(int argc, char *argv[]) {
	int r,theta;
	printf("Indique el valor del radio: ");
	scanf("%d",&r);
	printf("Indique el valor del angulo: ");
	scanf("%d",&theta);
	printf("El valor de X es: %f\n",CX(r,theta));
	printf("El valor de Y es: %f\n",CY(r,theta));
	system("pause");
	return 0;
}

float CX(float r,float an){
	float x;
	x=r*cos(an);
	return x;
}

float CY(float r,float an){
	float y;
	y=r*sin(an);
	return y;
}
