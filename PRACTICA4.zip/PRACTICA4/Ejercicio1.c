#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int a,h,l,i=0,total=0;
	
	for(i;i<3;i++){
	 
	 printf("Introdusca el valor de la altura:\t ");
	 scanf("%d",&h);
	 
	 printf("Introdusca el valor del ancho:\t\t");
	 scanf("%d",&a);
	 
	 printf("Introdusca el valor de la longitud:\t ");
	 scanf("%d",&l);
	 
	 printf("\nEl volumen es:\t %d\n\n",volumen(h,a,l));
	 
	 total+=volumen(h,a,l);
	}
	
	printf("\n\nEl volumen total es:\t %d\n",total);
	return 0;
}

int volumen(int altura,int ancho,int longitud){
	int v;
	v=altura*ancho*longitud;
	return v;
}

