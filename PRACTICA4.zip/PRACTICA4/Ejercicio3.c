#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int potencia(int base,int expo){
	int r;
	r=pow(base,expo);
	return r;
}

int main(int argc, char *argv[]) {
	int b,e;
	printf("Ingrese el numero base: ");
	scanf("%d",&b);
	printf("Ingrese el exponente: ");
	scanf("%d",&e);
	printf("El resultado es: %d\n",potencia(b,e));
	system("pause");
	return 0;
}
