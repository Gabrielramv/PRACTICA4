#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double hipotenusa(double a,double l){
	double h;
	h=sqrt((pow(a,2))+(pow(l,2)));
	return h;
}

int main(int argc, char *argv[]) {
	double l1,l2;
	printf("Indique el valor del lado 1: ");
	scanf("%lf",&l1);
	printf("Indique el valor del lado 1: ");
	scanf("%lf",&l2);
	printf("El valor de la hipotenusa es %lf\n",hipotenusa(l1,l2));
	system("pause");
	return 0;
}
